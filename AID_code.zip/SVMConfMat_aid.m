clc;
clear;
close all;
addpath('./libs/liblinear-2.1/matlab');

datasetname = 'aid/';
imagedir = strcat('../../images/',datasetname);
globalfeaturedir = strcat('./temp_data/glofeat/final/',datasetname);
savedir = strcat('./temp_data/acc_result/',datasetname);
mkdir (savedir);

classname = { 'Airp';'Bare';'Base';'Beach';'Bridge';'Center';...
    'Church';'Commer';'Dense R';'Desert';'Farm';'Forest';...
    'Indus';'Meadow';'Medium R';'Mount';'Park';'Parking';...
    'Play';'Pond';'Port';'Rail Sta';'Resort';'River';...
    'School';'Sparse R';'Square';'Stadium';'Storage';'Viaduct'};

globalfeaturename = dir(fullfile(strcat(globalfeaturedir,'*lbp256_grid_vlad*')));

acc = [];
kappa = [];
label = [];
ratio_train_test = 0.5;

train_vec = [];
test_vec = [];
train_label = [];
test_label = [];
R_train_all = [];
R_test_all = [];

fnames = dir(imagedir);
num_files = size(fnames,1);
num_class = num_files-2;
num_img_per_class = zeros(num_class,1);
globalfeatureall = [];

for img = 1:num_files
    
    if( (strcmp(fnames(img).name , '.')==1) || (strcmp(fnames(img).name , '..')==1))
        continue;
    end
    subfoldername = fnames(img).name;
    filename_tif = dir(fullfile(strcat(imagedir,subfoldername),'*.jpg'));
    num_img_per_class(img-2) = length(filename_tif);
    label = [label; (img-2)*ones(num_img_per_class(img-2),1)];
end

Rname = 'R_whu30_0.5.mat';
if(exist(Rname,'file')~=0)
    fprintf('Already exist %\n', Rname);
    load (Rname);
else
    for ic = 1:num_class
        
        R = randperm(num_img_per_class(ic));
        num_train = fix(num_img_per_class(ic)*ratio_train_test);
        R_train = R(1:num_train);
        R_test = R(num_train+1:end);
        
        R_train_all=[R_train_all,R_train+sum(num_img_per_class(1:ic-1,1))];
        R_test_all=[R_test_all,R_test+sum(num_img_per_class(1:ic-1,1))];
    end
    save (Rname, 'R_train_all', 'R_test_all')
end

for gf = 1: length(globalfeaturename)
    load (strcat(globalfeaturedir,globalfeaturename(gf).name));
    globalfeatureall = double(globalfeatureall);
%         globalfeatureall = double(cell2mat(denseFeatures)');
%         globalfeatureall = double(H_all);
    
    train_vec = globalfeatureall(R_train_all,:);
    test_vec =  globalfeatureall(R_test_all,:);
    train_label = label(R_train_all);
    test_label = label(R_test_all);
    
    train_vec = sparse(train_vec);
    test_vec = sparse(test_vec);
    model = train(train_label,train_vec,['-s 0 -c 100 -q']);

    [predict_label, accuracy_2nd, predict_prob]=predict(test_label,test_vec,model, '-b 1');
    acc = accuracy_2nd(1);
    
    num_train = fix(num_img_per_class*ratio_train_test);
    num_test = num_img_per_class-num_train;
    [confusion_matrix]=compute_confusion_matrix(predict_label,num_test,classname);
    close all;
    [confusion_matrix_n]=compute_confusion_matrix_n(predict_label,num_test);
    kappa = compute_kappa_coefficient(confusion_matrix_n, num_class, num_test)
    cfname = strcat(savedir,'confusion_matrix_',num2str(ratio_train_test),globalfeaturename(gf).name(17:end));%'_caffe.mat');
    save (cfname, 'confusion_matrix','predict_label','kappa','acc');
end